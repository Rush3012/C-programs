#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

struct c_queue {
    int str[100];
    int f, r;
};

struct c_graph {
    int** adjacent_graph;
    int vertex_num;
};

struct c_queue* create_queue() {
    struct c_queue* q = (struct c_queue*)malloc(sizeof(struct c_queue));
    q->f = -1;
    q->r = -1;
    return q;
}

void enqueue(struct c_queue* q, int value) {
    if (q->r == 99) {
        return;
    }
    if (q->f == -1) {
        q->f = 0;
    }
    q->r++;
    q->str[q->r] = value;
}

int dequeue(struct c_queue* q) {
    if (q->f == -1) {
        return -1;
    }
    int value = q->str[q->f];
    q->f++;
    if (q->f > q->r) {
        q->f = q->r = -1;
    }
    return value;
}

bool is_empty(struct c_queue* q) {
    return q->f == -1;
}

struct c_graph* create_graph(int vertex_num) {
    struct c_graph* g = (struct c_graph*)malloc(sizeof(struct c_graph));
    g->vertex_num = vertex_num;
    g->adjacent_graph = (int**)malloc(vertex_num * sizeof(int*));
    for (int i = 0; i < vertex_num; ++i) {
        g->adjacent_graph[i] = (int*)malloc(vertex_num * sizeof(int));
    }
    return g;
}

void add_edge(struct c_graph* g, int src, int dest) {
    g->adjacent_graph[src][dest] = 1;
}

int topological_sort(struct c_graph* g) {
    int in_degree[100] = {0};

    for (int i = 0; i < g->vertex_num; ++i) {
        for (int j = 0; j < g->vertex_num; ++j) {
            if (g->adjacent_graph[i][j] == 1) {
                in_degree[j]++;
            }
        }
    }

    struct c_queue* q = create_queue();

    for (int i = 0; i < g->vertex_num; ++i) {
        if (in_degree[i] == 0) {
            enqueue(q, i);
        }
    }

    int count = 0;

    while (!is_empty(q)) {
        int vertex = dequeue(q);
        count++;

        for (int i = 0; i < g->vertex_num; ++i) {
            if (g->adjacent_graph[vertex][i] == 1) {
                in_degree[i]--;
                if (in_degree[i] == 0) {
                    enqueue(q, i);
                }
            }
        }
    }

    if (count != g->vertex_num) {
        return -1;
    }

    return 1;
}

int count_strongly_connected(struct c_graph* g) {
    int count = 0;

    bool visited[100] = {false};

    for (int i = 0; i < g->vertex_num; ++i) {
        if (!visited[i]) {
            struct c_queue* q = create_queue();
            enqueue(q, i);
            visited[i] = true;
            while (!is_empty(q)) {
                int vertex = dequeue(q);
                for (int j = 0; j < g->vertex_num; ++j) {
                    if (g->adjacent_graph[j][vertex] == 1 && !visited[j]) {
                        enqueue(q, j);
                        visited[j] = true;
                    }
                }
            }
            count++;
        }
    }

    return count;
}

int main() {
    int vertex_num;
    char user_command;
    scanf("%d", &vertex_num);
    struct c_graph* g = create_graph(vertex_num);

    for (int i = 0; i < vertex_num; ++i) {
        for (int j = 0; j < vertex_num; ++j) {
            scanf("%d", &g->adjacent_graph[i][j]);
        }
    }

    while (1) {
        scanf(" %c", &user_command);

        switch (user_command) {
            case 't':
                printf("%d\n", topological_sort(g));
                break;
            case 'c':
                printf("%d\n", count_strongly_connected(g));
                break;
            case 'x':
                return 0;
        }
    }

    return 1;
}
