#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NODES 100

int adjacency[MAX_NODES][MAX_NODES + 1]; // Adjacency list representation
int visited[MAX_NODES] = {0};
int currentPath[MAX_NODES];
int numNodes;

void printCurrentPath(int path[], int length) {
    for (int i = 0; i < length; i++) {
        printf("%d ", path[i]);
    }
    printf("\n");
}

void findAllPathsUtil(int source, int destination, int path[], int pathLength) {
    visited[source] = 1;
    path[pathLength] = source;
    pathLength++;

    if (source == destination) {
        printCurrentPath(path, pathLength);
    } else {
        for (int i = 1; i <= adjacency[source][0]; i++) {
            int adjacentNode = adjacency[source][i];
            if (!visited[adjacentNode]) {
                findAllPathsUtil(adjacentNode, destination, path, pathLength);
            }
        }
    }

    pathLength--;
    visited[source] = 0;
}

void findAllPaths(int source, int destination) {
    memset(visited, 0, sizeof(visited));
    findAllPathsUtil(source, destination, currentPath, 0);
}

int isCyclicUtil(int vertex, int parent) {
    visited[vertex] = 1;
    for (int i = 1; i <= adjacency[vertex][0]; i++) {
        int adjacentNode = adjacency[vertex][i];

        if (!visited[adjacentNode]) {
            if (isCyclicUtil(adjacentNode, vertex))
                return 1;
        } else if (adjacentNode != parent) {
            return 1;
        }
    }
    return 0;
}

int isConnected() {
    memset(visited, 0, sizeof(visited));
    isCyclicUtil(0, -1); // Start DFS from node 0, assuming 0 is always a part of the graph for simplicity.
    for (int i = 0; i < numNodes; i++) {
        if (!visited[i])
            return 0; // Node i is not connected
    }
    return 1; // All nodes are connected
}

void checkIfTree() {
    memset(visited, 0, sizeof(visited));
    if (isCyclicUtil(0, -1) == 0 && isConnected())
        printf("1\n"); // Graph is a tree
    else
        printf("-1\n"); // Graph is not a tree
}

int main() {
    scanf("%d", &numNodes);
    for (int i = 0; i < numNodes; i++) {
        int node, neighborCount = 0, neighbor;
        scanf("%d", &node);
        while (scanf("%d", &neighbor) == 1) {
            adjacency[node][++neighborCount] = neighbor;
            char character = getchar();
            if (character == '\n' || character == EOF) break;
        }
        adjacency[node][0] = neighborCount; // Store the count of neighbors at index 0
    }

    char command;
    while (scanf(" %c", &command) && command != 'x') {
        if (command == 'a') {
            int source, destination;
            scanf("%d %d", &source, &destination);
            findAllPaths(source, destination);
        } else if (command == 't') {
            checkIfTree();
        }
    }

    return 0;
}

